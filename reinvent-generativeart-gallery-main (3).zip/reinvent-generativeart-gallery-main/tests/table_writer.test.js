const fs = require('fs');
const { init, record_submission } = require('./yourModule'); // Adjust path if necessary
const { DynamoDBClient, ListTablesCommand, CreateTableCommand, waitUntilTableExists } = require("@aws-sdk/client-dynamodb");
const { PutCommand, DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");

jest.mock('@aws-sdk/client-dynamodb');
jest.mock('@aws-sdk/lib-dynamodb');
jest.mock('fs');

describe('Security tests for init and record_submission', () => {
    const mockDynamoDBClient = new DynamoDBClient();
    const mockDocClient = DynamoDBDocumentClient.from(mockDynamoDBClient);

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('init function', () => {
        test('should handle lack of DynamoDB permissions gracefully', async () => {
            // Mock ListTablesCommand to throw an AccessDeniedException
            mockDynamoDBClient.send.mockImplementationOnce((command) => {
                if (command instanceof ListTablesCommand) {
                    return Promise.reject({ code: 'AccessDeniedException', message: 'User is not authorized' });
                }
            });

            await expect(init()).rejects.toEqual({ code: 'AccessDeniedException', message: 'User is not authorized' });
            expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Table list throws err'));
        });

        test('should attempt to create table if not present', async () => {
            mockDynamoDBClient.send.mockImplementation((command) => {
                if (command instanceof ListTablesCommand) {
                    return Promise.resolve({ TableNames: [] });
                } else if (command instanceof CreateTableCommand) {
                    return Promise.resolve();
                }
            });

            await init();

            expect(mockDynamoDBClient.send).toHaveBeenCalledWith(expect.any(ListTablesCommand));
            expect(mockDynamoDBClient.send).toHaveBeenCalledWith(expect.any(CreateTableCommand));
            expect(waitUntilTableExists).toHaveBeenCalled();
        });
    });

    describe('record_submission function', () => {
        test('should handle error when incrementing order number', async () => {
            fs.readFileSync.mockImplementationOnce(() => {
                throw new Error("File read error");
            });

            await expect(record_submission({ model: 'Stable Diffusion', prompt: 'Test Prompt' }, 's3://bucket/test-key.png'))
                .rejects.toThrow('File read error');

            expect(fs.readFileSync).toHaveBeenCalled();
            expect(console.error).toHaveBeenCalledWith('Error reading counter.txt:', expect.any(Error));
        });

        test('should handle DynamoDB permission error on PutCommand', async () => {
            fs.readFileSync.mockReturnValue('0'); // Mock order number increment
            fs.writeFileSync.mockImplementationOnce(() => {}); // Mock successful write

            mockDocClient.send.mockImplementationOnce((command) => {
                if (command instanceof PutCommand) {
                    return Promise.reject({ code: 'AccessDeniedException', message: 'User is not authorized to perform this action' });
                }
            });

            await expect(record_submission({ model: 'Stable Diffusion', prompt: 'Test Prompt' }, 's3://bucket/test-key.png'))
                .rejects.toEqual({ code: 'AccessDeniedException', message: 'User is not authorized to perform this action' });

            expect(console.log).toHaveBeenCalledWith(expect.stringContaining("Table write throws err"));
        });

        test('should handle error when writing current image key file', async () => {
            fs.readFileSync.mockReturnValue('1'); // Mock order number increment
            fs.writeFileSync.mockImplementationOnce(() => {
                throw new Error('File write error');
            });

            mockDocClient.send.mockResolvedValue(); // Mock successful PutCommand

            await record_submission({ model: 'Stable Diffusion', prompt: 'Test Prompt' }, 's3://bucket/test-key.png');

            expect(console.error).toHaveBeenCalledWith(expect.stringContaining('Failed to write to /home/ec2-user/reinvent-generativeart-gallery/js/server/current_image_key.txt'));
        });
    });
});

