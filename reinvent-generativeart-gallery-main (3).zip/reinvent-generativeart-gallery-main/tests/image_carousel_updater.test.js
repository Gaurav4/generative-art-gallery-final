const AWS = require('aws-sdk');
const updateCarousel = require('../js/server/image_carousel_updater'); // Adjust path if necessary

jest.mock('aws-sdk', () => {
    const mockS3 = { getObject: jest.fn() };
    const mockDynamoDB = { scan: jest.fn() };
    return {
        S3: jest.fn(() => mockS3),
        DynamoDB: {
            DocumentClient: jest.fn(() => mockDynamoDB)
        }
    };
});

describe('Security test for updateCarousel', () => {
    const mockDynamoDB = new AWS.DynamoDB.DocumentClient();
    const mockS3 = new AWS.S3();

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should handle lack of DynamoDB permissions gracefully', async () => {
        // Mock DynamoDB to throw a permissions error
        mockDynamoDB.scan.mockReturnValueOnce({
            promise: jest.fn().mockRejectedValue({ code: 'AccessDeniedException', message: 'User is not authorized to perform this action' })
        });

        const result = await updateCarousel();

        expect(mockDynamoDB.scan).toHaveBeenCalled();
        expect(result).toEqual([]);
        expect(console.error).toHaveBeenCalledWith(
            'Error fetching data from DynamoDB:',
            expect.objectContaining({ code: 'AccessDeniedException' })
        );
    });

    test('should handle lack of S3 permissions gracefully for some images', async () => {
        // Mock DynamoDB scan to return approved items
        mockDynamoDB.scan.mockReturnValueOnce({
            promise: jest.fn().mockResolvedValue({
                Items: [
                    { id: '1', sortkey: '2024-10-20', modelId: 'model1', modelname: 'Model 1', prompt: 'Test Prompt', s3filepath: 's3://bucket/path1.png' },
                    { id: '2', sortkey: '2024-10-19', modelId: 'model2', modelname: 'Model 2', prompt: 'Another Prompt', s3filepath: 's3://bucket/path2.png' }
                ]
            })
        });

        // Mock S3 getObject to throw an error for one item due to missing permissions
        mockS3.getObject.mockImplementation((params) => {
            if (params.Key === '1.png') {
                return { promise: jest.fn().mockRejectedValue({ code: 'AccessDenied', message: 'Access Denied' }) };
            }
            return { promise: jest.fn().mockResolvedValue({ Body: Buffer.from('image-data') }) };
        });

        const result = await updateCarousel();

        expect(mockDynamoDB.scan).toHaveBeenCalled();
        expect(mockS3.getObject).toHaveBeenCalledTimes(2);
        expect(console.error).toHaveBeenCalledWith(
            'Error fetching image from S3 for s3://bucket/path1.png:',
            expect.objectContaining({ code: 'AccessDenied' })
        );

        // Verify that only the accessible image is included
        expect(result).toEqual([
            {
                id: '2',
                modelId: 'model2',
                modelname: 'Model 2',
                prompt: 'Another Prompt',
                s3filepath: 's3://bucket/path2.png',
                imageData: Buffer.from('image-data').toString('base64'),
                sortkey: '2024-10-19',
            }
        ]);
    });
});

