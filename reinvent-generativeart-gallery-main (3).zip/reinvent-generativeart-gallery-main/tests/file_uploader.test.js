const { S3Client } = require("@aws-sdk/client-s3");
const upload_image = require('../js/server/file_uploader');

jest.mock("@aws-sdk/lib-storage");
jest.mock("@aws-sdk/client-s3");
jest.mock('uuid');

describe('upload_image security tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.S3Bucket = 'reinvent-generativeart-galleryv2';
    process.env.region = 'us-west-2';
  });

  test('should set ACL to private when uploading', async () => {
    const mockUpload = jest.fn().mockReturnValue({
      done: jest.fn().mockResolvedValue({ Location: 'https://reinvent-generativeart-galleryv2.s3.us-west-2.amazonaws.com/02b6f71c-a5b9-43c3-babe-ea540eb1a9a9.png' })
    });
    require("@aws-sdk/lib-storage").Upload.mockImplementation(mockUpload);

    const uploadParams = {
      imagebase64: Buffer.from('test-image').toString('base64'),
    };

    await upload_image(uploadParams);

    expect(mockUpload).toHaveBeenCalledWith(
      expect.objectContaining({
        params: expect.objectContaining({
          ACL: 'private',
          Bucket: 'reinvent-generativeart-galleryv2',
          ContentType: 'image/png',
          ContentEncoding: 'base64'
        })
      })
    );
  });
});
