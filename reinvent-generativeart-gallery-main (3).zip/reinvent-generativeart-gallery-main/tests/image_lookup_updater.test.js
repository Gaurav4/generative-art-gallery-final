const AWS = require('aws-sdk');
const update360 = require('./update360'); // Adjust path if necessary

jest.mock('aws-sdk', () => {
    const mockDynamoDB = { scan: jest.fn() };
    return {
        DynamoDB: {
            DocumentClient: jest.fn(() => mockDynamoDB)
        }
    };
});

describe('Security test for update360', () => {
    const mockDynamoDB = new AWS.DynamoDB.DocumentClient();

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should handle missing order number gracefully', async () => {
        const result = await update360();
        expect(result).toEqual({ error: 'Order number is required' });
    });

    test('should handle lack of DynamoDB permissions gracefully', async () => {
        // Mock DynamoDB to throw a permissions error
        mockDynamoDB.scan.mockReturnValueOnce({
            promise: jest.fn().mockRejectedValue({ code: 'AccessDeniedException', message: 'User is not authorized to perform this action' })
        });

        const result = await update360('12345');

        expect(mockDynamoDB.scan).toHaveBeenCalledWith({
            TableName: 'reinvent-generativeart-galleryv2',
            FilterExpression: "approved = :approved and orderNumber = :orderNumber",
            ExpressionAttributeValues: {
                ":approved": true,
                ":orderNumber": '12345'
            }
        });
        expect(result).toEqual({ error: 'Failed to retrieve data from DynamoDB' });
        expect(console.error).toHaveBeenCalledWith(
            'Error fetching data from DynamoDB:',
            expect.objectContaining({ code: 'AccessDeniedException' })
        );
    });

    test('should handle no items found for valid order number', async () => {
        // Mock DynamoDB to return an empty result
        mockDynamoDB.scan.mockReturnValueOnce({
            promise: jest.fn().mockResolvedValue({ Items: [] })
        });

        const result = await update360('12345');

        expect(result).toEqual({ error: 'No image found for the provided order number' });
    });

    test('should return item details if DynamoDB query is successful', async () => {
        const mockData = {
            Items: [
                {
                    id: '1',
                    modelId: 'model123',
                    modelname: 'Test Model',
                    prompt: 'Sample prompt',
                    s3filepath: 'https://s3.amazonaws.com/sample/path/to/image.png',
                    sortkey: 'sort123',
                },
            ],
        };

        // Mock DynamoDB to return a successful response with items
        mockDynamoDB.scan.mockReturnValueOnce({
            promise: jest.fn().mockResolvedValue(mockData)
        });

        const result = await update360('12345');

        expect(result).toEqual({
            id: '1',
            modelId: 'model123',
            modelname: 'Test Model',
            prompt: 'Sample prompt',
            s3filepath: 'https://s3.amazonaws.com/sample/path/to/image.png',
            sortkey: 'sort123',
        });
    });
});

