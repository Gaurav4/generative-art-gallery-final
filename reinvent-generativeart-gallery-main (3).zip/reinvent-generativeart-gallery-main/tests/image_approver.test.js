const AWS = require('aws-sdk');
const { getUnapprovedRecords, approvePrompts, denyPrompt } = require('../js/server/image_approver'); // Adjust path
const upload_image = require('../js/server/file_uploader');
const invoke_bedrock = require('./bedrock_client');

jest.mock('aws-sdk');
jest.mock('../js/server/file_uploader');
jest.mock('./bedrock_client');

const mockDynamoDB = {
    scan: jest.fn(),
    get: jest.fn(),
    update: jest.fn(),
};
AWS.DynamoDB.DocumentClient = jest.fn(() => mockDynamoDB);

describe('getUnapprovedRecords', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should fetch unapproved records from DynamoDB', async () => {
        const mockData = {
            Items: [
                { id: 'be8b2624-cb13-4139-942f-7a32ea9815a4', approved: false, prompt: 'a delightful get away resort in hawaii with alot of people', s3filepath: null },
            ],
        };
        mockDynamoDB.scan.mockReturnValue({ promise: jest.fn().mockResolvedValue(mockData) });

        const result = await getUnapprovedRecords();
        expect(mockDynamoDB.scan).toHaveBeenCalledWith({
            TableName: 'reinvent-generativeart-gallery',
            FilterExpression: "approved = :approved",
            ExpressionAttributeValues: { ":approved": false },
            ProjectionExpression: "id, approved, prompt, s3filepath",
        });
        expect(result).toEqual(mockData.Items);
    });
});

describe('approvePrompts', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should approve prompts, upload images to S3, and update DynamoDB records', async () => {
        const mockItems = [
            { id: '1', Item: { id: '1', prompt: 'Sample prompt' } },
        ];
        const mockImageData = 'base64imageData';
        const mockS3Uri = 'https://reinvent-generativeart-galleryv2.s3.us-west-2.amazonaws.com/be8b2624-cb13-4139-942f-7a32ea9815a4.png';

        mockDynamoDB.get.mockReturnValueOnce({ promise: jest.fn().mockResolvedValue(mockItems[0]) });
        invoke_bedrock.mockResolvedValueOnce({ body: { buffer: Buffer.from(JSON.stringify({ artifacts: [{ base64: mockImageData }] })) } });
        upload_image.mockResolvedValueOnce(mockS3Uri);
        mockDynamoDB.update.mockReturnValue({ promise: jest.fn().mockResolvedValue(true) });

        await approvePrompts(['1']);

        expect(invoke_bedrock).toHaveBeenCalledWith({ prompt: 'Sample prompt', seed: expect.any(Number) }, "Stable Diffusion");
        expect(upload_image).toHaveBeenCalledWith({ imagebase64: mockImageData });
        expect(mockDynamoDB.update).toHaveBeenCalledWith({
            TableName: 'reinvent-generativeart-gallery',
            Key: { id: '1' },
            UpdateExpression: "set approved = :approved, s3filepath = :s3filepath",
            ExpressionAttributeValues: { ":approved": true, ":s3filepath": mockS3Uri },
        });
    });
});

describe('denyPrompt', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should set approved field to "denied" in DynamoDB for given ids', async () => {
        const mockIds = ['1', '2'];
        mockDynamoDB.update.mockReturnValue({ promise: jest.fn().mockResolvedValue(true) });

        await denyPrompt(mockIds);

        mockIds.forEach((id) => {
            expect(mockDynamoDB.update).toHaveBeenCalledWith({
                TableName: 'reinvent-generativeart-gallery',
                Key: { id },
                UpdateExpression: "set approved = :approved",
                ExpressionAttributeValues: { ":approved": "denied" },
            });
        });
    });
});

