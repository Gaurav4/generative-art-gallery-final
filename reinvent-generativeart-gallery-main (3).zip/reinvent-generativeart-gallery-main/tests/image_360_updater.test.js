const AWS = require('aws-sdk');
const update360 = require('../js/server/image_360_updater'); // Adjust path if necessary

// Mock DynamoDB DocumentClient
const mockDynamoDB = {
    scan: jest.fn(),
};
AWS.DynamoDB.DocumentClient = jest.fn(() => mockDynamoDB);

describe('update360', () => {
    const tableName = 'reinvent-generativeart-galleryv2';

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should return the item data when a valid order number is provided', async () => {
        const mockOrderNumber = '1009';
        const mockData = {
            Items: [
                {
                    id: '27d92994-e2fd-4f15-9225-7a95737c5023',
                    modelId: 'amazon.titan-image-generator-v1',
                    modelname: 'Amazon Titan',
                    prompt: 'a getaway island in the middle of the Bahamas',
                    s3filepath: 'https://reinvent-generativeart-galleryv2.s3.us-west-2.amazonaws.com/28e48793-a335-48d4-b489-355ed43af0e3.png',
                    sortkey: '20241019132224441',
                },
            ],
        };

        // Mock DynamoDB response
        mockDynamoDB.scan.mockReturnValue({
            promise: jest.fn().mockResolvedValue(mockData),
        });

        const result = await update360(mockOrderNumber);

        expect(mockDynamoDB.scan).toHaveBeenCalledWith({
            TableName: tableName,
            FilterExpression: "approved = :approved and orderNumber = :orderNumber",
            ExpressionAttributeValues: {
                ":approved": true,
                ":orderNumber": mockOrderNumber,
            },
        });

        expect(result).toEqual({
            id: '1',
            modelId: 'model123',
            modelname: 'Test Model',
            prompt: 'Sample prompt',
            s3filepath: 'https://s3.amazonaws.com/sample/path/to/image.png',
            sortkey: 'sort123',
        });
    });

    test('should return an error when no order number is provided', async () => {
        const result = await update360();

        expect(result).toEqual({ error: 'Order number is required' });
    });

    test('should return an error when no item is found for the provided order number', async () => {
        const mockOrderNumber = '12345';

        // Mock DynamoDB response with no items found
        mockDynamoDB.scan.mockReturnValue({
            promise: jest.fn().mockResolvedValue({ Items: [] }),
        });

        const result = await update360(mockOrderNumber);

        expect(result).toEqual({ error: 'No image found for the provided order number' });
    });

    test('should return an error when DynamoDB fails', async () => {
        const mockOrderNumber = '12345';

        // Mock DynamoDB to throw an error
        mockDynamoDB.scan.mockReturnValue({
            promise: jest.fn().mockRejectedValue(new Error('DynamoDB error')),
        });

        const result = await update360(mockOrderNumber);

        expect(result).toEqual({ error: 'Failed to retrieve data from DynamoDB' });
    });
});

